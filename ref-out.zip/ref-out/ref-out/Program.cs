﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ref_out
{
    class Program
    {
        public static int get(ref int i)
        {
            i++;
            return i;
        }
        public static int get1(out int i)
        {
            i = 1;
            return i;
        }
        static void Main(string[] args)
        {
            int i = 0;
            Console.Write(get(ref i));
            Console.Write(get1(out i));
            Console.Read();
        }
    }
}
