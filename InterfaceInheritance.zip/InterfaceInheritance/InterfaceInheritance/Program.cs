﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InterfaceInheritance
{
    public interface A
    {
        void mymethod1();
        void mymethod2();
    }

    public interface B : A
    {
        void mymethod3();
    }

    class Geeks : B
    {
        public void mymethod1()
        {
            Console.WriteLine("Implement method 1");
        }

        public void mymethod2()
        {
            Console.WriteLine("Implement method 2");
        }

        public void mymethod3()
        {
            Console.WriteLine("Implement method 3");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Geeks obj = new Geeks();
            obj.mymethod1();
            obj.mymethod2();
            obj.mymethod3();
            Console.Read();
        }
    }
}
