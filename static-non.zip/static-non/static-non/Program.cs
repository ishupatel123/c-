﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace static_non
{
    class Program
    {
        public static int send(int x)
        {
            return x;
        }
        public  int get(int x)
        {
            return x;
        }
        static void Main(string[] args)
        {
            Program p=new Program();
            Console.Write(p.get(1));

            Console.Write(send(1));
            Console.Read();
        }
    }
}
