﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UsingProperties
{
    public class Student
    {
        private static int cnt;
        private string name = "BCA4";
        public Student()
        {
            cnt++;
        }

        public static int Counter
        {
            get
            {
                return cnt;
            }
        }
        public string Name
        {
            get
            {
                return name;
            }

            set
            {
                name = value;
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Student s = new Student();
            Student s1 = new Student();
            Student s2 = new Student();
            Student s3 = new Student();
            Console.WriteLine("Total No of Student: " + Student.Counter);
            s.Name = "BSCIT4";
            Console.WriteLine("Name: " + s.Name);
            Console.Read();
        }
    }
}
