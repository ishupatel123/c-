﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace whileloop
{
    class Program
    {
        static void Main(string[] args)
        {


            .
            Console.Write("enter any number:");
            int n = Convert.ToInt32(Console.ReadLine());
            int i = 1, a = 2, b = 3;
            while (i <= n)
            {

                if (i <= 3)
                {
                    Console.Write(i + " ");
                    i++;
                }
                else
                {
                    i = a * b;
                    if (i >= n)
                    {
                        break;
                    }
                    Console.Write(i + " ");
                    a = b;
                    b = i;
                }
            }


            Console.Read();
        }
    }
}

