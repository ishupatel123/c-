﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace unit1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("enter  name:");
            string a = Console.ReadLine();
            Console.Write(a);
            Console.Read();
        }
    }
}
