﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace crud1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

       

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Employee emp = new Employee();
            emp.Show();

        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Class1.menuitem = 0;
            Employee emp = new Employee();
            emp.Show();
        }

        private void updateEmployeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Class1.menuitem = 2;
            Employee emp = new Employee();
            emp.Show();
        }

        private void employeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Class1.menuitem = 1;
            Employee emp = new Employee();
            emp.Show();
        }

        private void employeeToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Class1.menuitem = 3;
            Employee emp = new Employee();
            emp.Show();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            Employee emp = new Employee();
            emp.Show();
        }

       
     }
}
