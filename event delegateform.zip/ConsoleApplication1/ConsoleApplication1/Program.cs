﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;


namespace ConsoleApplication1
{
    public delegate void DelEvenHendler();
    class Program:Form
    {
        public event DelEvenHendler add;

        public Program()
        {

            Button btn = new Button();
            btn.Parent = this;
            btn.Text = "CLICK ME..!";
            btn.Location = new Point(100, 100);

            btn.Click += new EventHandler(onclick);
        }
        public void onclick(object sender, EventArgs e)
        {
            MessageBox.Show("clicked");
        }
        static void Main(string[] args)
        {
            Application.Run(new Program());
            Console.Read();
        }
    }
}
